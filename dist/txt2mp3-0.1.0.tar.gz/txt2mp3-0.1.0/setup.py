# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['txt2mp3']

package_data = \
{'': ['*']}

install_requires = \
['gtts>=2.3.0,<3.0.0', 'rich-click>=1.6.0,<2.0.0']

entry_points = \
{'console_scripts': ['greet = txt2mp3.translate:cli']}

setup_kwargs = {
    'name': 'txt2mp3',
    'version': '0.1.0',
    'description': '',
    'long_description': "A Python program to convert a .txt file, in English, into an MP3 audio file, with choice of English language accent\n\nKnown to work on Python versions >= Python 9.0\n\n\n\nWELCOME to TXT_2_MP3\n\nEnter the path and filename of the .txt file, to convert from text to speech (example: 'readthis.txt').\n\n: readthis.txt\n\nPlease choose an English accent (type a number and hit ENTER)\n\n        1. English (Australia)\n        2. English (United Kingdom)\n        3. English (United States)\n        4. English (Canada)\n        5. English (India)\n        6. English (Ireland)\n        7. English (South Africa)\n\n: 6\n\n\nMP3 file created at /mp3s/readthis.mp3\n\nFor a long text, such as several pages, it could take a few minuted for the mp3 file to be rendered.\n\nMP3s are always saved to 'mp3s' folder one level down from the current one. If the 'mp3s' folder does not exist, it will be created.\n\nIf the filename given does not exist, the program will exit. However, if the choice of accent is not within the range, the default of American English will be applied.\n\n.docx files can be used, in certain circumstances. For example, creating a .docx file in your IDE and pasting in code may work, but using a .docx file which has been formatted in MS Word will result in an error.\n\nTip: When pasting from a web page or Word doc, delete the image file names or it will read them (they are often long). Delete long numbers are any phrases which are not normally spoken, such as URLs.\n\nCredit: Much was borrowed from John Capobianco's wiktrola project for this: https://www.youtube.com/watch?v=HbHaZRWq3_I",
    'author': 'Alexander Stevenson',
    'author_email': '27918923+xanderstevenson@users.noreply.github.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
